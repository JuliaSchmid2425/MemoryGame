package forms;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FrontPage {

    /**
     * declaració de tots els elements que sortiran a la pantalla
     */

    private JFrame frame;
    private JPanel panelMain;
    private JPanel panelUser;
    private JPanel panelTop;
    private JPanel panelBottom;
    private JLabel labelUser;
    private JTextField fieldUserName;
    private JButton buttonStart;
    private JLabel labelTitle;
    private JLabel labelInstructions1;
    private JLabel labelInstructions2;

    /**
     * @param username guarda el nom d'usuari introduït
     */
    protected String username;


    /**
     * constructor de la pàgina principal
     */
    public FrontPage() {
        initializeComponents();
        setupFrame();
        showPanelTop();
        showPanelUser();
        showPanelBottom();

    }

    /**
     * crea nova instància dels elements
     * defineix el layout i el seu format
     */
    private void initializeComponents() {
        panelMain = new JPanel(new BorderLayout());
        panelTop = new JPanel(new GridLayout(3, 1, 5, 5));
        panelUser = new JPanel(new GridLayout(1,2,5,5));
        panelBottom = new JPanel(new FlowLayout(FlowLayout.CENTER));

        /**
         * crea un marge al voltant de tota la finestra
         */
        panelMain.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

    }

    /**
     * defineix part superior finestra
     */
    private void showPanelTop(){
        /**
         * defineix mida tenint en compte l'amplada de {@see setupFrame}
         */
        panelTop.setSize(new Dimension(frame.getWidth(), 150));
        panelTop.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));

        labelTitle = new JLabel("Benvinguda o benvigut al joc del memory!");
        labelTitle.setFont(new Font("Arial", Font.BOLD, 24));
        labelTitle.setHorizontalAlignment(SwingConstants.CENTER);

        /**
         * explica instruccions del joc.
         * defineix marge
         * alinea label a l'esquerra
         */
        labelInstructions1 = new JLabel("- per cada parella que aconsegueixis, se't sumarà 1 punt.");
        labelInstructions2 = new JLabel( "- si aconsegueixes una parella sense haver-ne girat cap de les dues prèviament, se t'atorgaran 5 punts.");
        labelInstructions1.setBorder(BorderFactory.createEmptyBorder(5, 50, 5, 50));
        labelInstructions2.setBorder(BorderFactory.createEmptyBorder(5, 50, 5, 50));
        labelInstructions1.setHorizontalAlignment(SwingConstants.LEFT);
        labelInstructions2.setHorizontalAlignment(SwingConstants.LEFT);


        /**
         * afegeix labels al panel
         */
        panelTop.add(labelTitle);
        panelTop.add(labelInstructions1);
        panelTop.add(labelInstructions2);

        /**
         * afegeix al panel principal
         */
        panelMain.add(panelTop, BorderLayout.NORTH);
    }

    /**
     * defineix panel on s'introdueix el username
     */
    private void showPanelUser(){

        /**
         * defineix mida i marges
         */
        panelUser.setMaximumSize(new Dimension(frame.getWidth(), 60));
        panelUser.setBorder(BorderFactory.createEmptyBorder(50, 200, 50, 200));

        /**
         * posa label i field en horitzontal un al costat de l'altre
         */
        panelUser.setLayout(new BoxLayout(panelUser, BoxLayout.X_AXIS));

        /**
         * defineix text label
         * defineix amplada field (caben aprox. 25 caràcters)
         * defineix mida màxima
         */
        labelUser = new JLabel("Nom d'usuari: ");
        fieldUserName = new JTextField(25);
        fieldUserName.setMaximumSize(new Dimension(panelUser.getWidth()/2, 20));

        /**
         * afegeix elements al panel
         */
        panelUser.add(labelUser);
        panelUser.add(fieldUserName);

        /**
         * afegeix al panel principal
         */
        panelMain.add(panelUser, BorderLayout.CENTER);
    }

    /**
     * defineix panel amb botó per començar partida
     * programa click sobre el botó
     */
    private void showPanelBottom(){
        /**
         * defineix text i mida botó
         */
        buttonStart.setPreferredSize(new Dimension(frame.getWidth()/2, 30));
        buttonStart= new JButton("Comença el joc!");

        /**
         * afegeix boto al panel
         * defineix marge i mida panel
         */
        panelBottom.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        panelBottom.setSize(new Dimension(frame.getWidth(), 80));
        panelBottom.add(buttonStart);

        /**
         * afegeix al panel principal
         */
        panelMain.add(panelBottom, BorderLayout.SOUTH);

        /**
         * defineix acció sobre botó
         *
         * comprova que el nom no estigui buit
         * @see startGame() cirda metode i passa username
         */
        buttonStart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                username = fieldUserName.getText().trim();
                if (!username.isEmpty()) {
                    startGame(username);
                } else {
                    JOptionPane.showMessageDialog(frame,
                            "Si us plau, introdueix un nom d'usuari",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    /**
     * defineix el frame
     */
    private void setupFrame() {
        /**
         * defineix tìtol, mida i layout
         */
        frame = new JFrame("Pàgina inicial");
        /**
         * programa para quan es tanca la finestra
         */
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(750, 500);
        frame.setMaximumSize(new Dimension(frame.getWidth(), frame.getHeight()));

        frame.setLayout(new BorderLayout());
        /**
         * afegeix panelMain
         * frame és visible
         */
        frame.setContentPane(panelMain);
        frame.setVisible(true);
    }

    private void startGame(String username) {
        /**
         * tanca el frame
         */
        frame.dispose();

        /**
         * Crea nova instància de {@link forms.MemoryGame} cridant al constructor
         * @param username passa al constructor
         */
        new MemoryGame(username);
    }
}