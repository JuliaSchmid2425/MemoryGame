package forms;

import database.DatabaseManager;

import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class MemoryGame{

    /**
     * declaració de tots els elements que sortiran a la pantalla
     */

    private JFrame frame;
    private JPanel panelMain;
    private JPanel panelInfo;
    private JPanel panelGame;
    private JLabel labelTime;
    private JLabel labelPairs;
    private JLabel labelErrors;
    private JLabel labelPoints;
    private JLabel labelUser;

    /**
     * numero de columnes i files
     * total parelles de cartes
     * array amb valors de les cartes
     */
    private static final int CARDS_ROW_COLUMN = 4;
    private static final int TOTAL_PAIRS = 8;
    private static final String[] CARD_VALUES = {":)", ":p", "<3", ":D", ":v", "uwu", "o.0", ":3"};

    /**
     * inicialitza a 0
     */
    private int foundPairs = 0;
    private int pointsCounter= 0;
    private int errorPoints = 0;
    private int seconds = 0;
    /**
     * declara timer
     */
    private Timer gameTimer;

    /**
     * inicialitza a valors que permeten el correcte fluxe del codi
     */
    private int firstCardIndex = -1;
    private int secondCardIndex = -1;
    private boolean isProcessing = false;

    /**
     * hashMap on
     *      key: index primera carta parella
     *      value: index segona carta parella
     */
    private Map<Integer, Integer> cardPairs = new HashMap<>();


    /**
     * guarda index de cartes que s'han girat
     */
    private Set<Integer> revealedCards = new HashSet<>();

    /**
     * guarda num vegades index de la carta s'ha girat
     *      key: index carta
     *      value: num vegades s'ha girat
     */
    private Map<Integer, Integer> cardRevealCount = new HashMap<>();

    /**
     * crea tots els jbuttons/cartes
     */
    private JButton[] cards = new JButton[CARDS_ROW_COLUMN * CARDS_ROW_COLUMN];

    //array de 16 cartes amb disseny (8 parelles)
    /**
     * array  que tindrà el text que surt a les cartes
     */
    private String[] gameCards = new String[CARDS_ROW_COLUMN * CARDS_ROW_COLUMN];

    /**
     *  guardar les dades per insertar-les a la bd
     */
    private final String username;
    private int pointsDB;
    private int errorsDB;
    private int durationSecondsDB;

    /**
     * constructor del joc
     * @param username obtingut de FrontPage
     */
    public MemoryGame(String username) {

        /**
         * guarda username de frontpage
         */
        this.username = username;

        /**
         * inicialitza panels
         * defineix layout i gap
         */
        panelMain = new JPanel(new BorderLayout());
        panelInfo = new JPanel(new GridLayout(1, 5)); //1 fila 4 columnes
        panelGame = new JPanel(new GridLayout(CARDS_ROW_COLUMN, CARDS_ROW_COLUMN, 5, 5)); //gap entre cartes de 5

        /**
         * inicialitza labels amb informacio sobre la partida
         * defneix text i posició
         */
        labelPairs = new JLabel("Parelles trobades: " + foundPairs + "/8", SwingConstants.CENTER);
        labelPoints = new JLabel("Punts: " + pointsCounter, SwingConstants.CENTER);
        labelErrors = new JLabel("Errors: " + errorPoints, SwingConstants.CENTER);
        labelTime = new JLabel("Temps: " + seconds + "s", SwingConstants.CENTER);
        labelUser = new JLabel("Usuari: " + username, SwingConstants.CENTER);


        /**
         * inicialitza i defineix JFrame
         */
        frame = new JFrame("MemoryGame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 750);
        frame.setLayout(new BorderLayout());
        frame.setContentPane(panelMain);
        frame.setBackground(Color.white);
        /**
         * marca com a visible
         */
        frame.setVisible(true);


        showPanelInfo();
        showPanelGame();
        createCardPairs();
        createCardsDesign();
        startGameTimer();
    }

    /**
     * Timer de la durada de la partida
     */
    private void startGameTimer() {
        gameTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                seconds++;
                labelTime.setText("Temps: " + seconds + "s");
            }
        });
        /**
         * inicia el timer
         */
        gameTimer.start();
    }


    /**
     * afegeix elements al panel on es mostra info sobre la partida
     */
    private void showPanelInfo() {
        panelInfo.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        panelInfo.add(labelPairs);
        panelInfo.add(labelPoints);
        panelInfo.add(labelErrors);
        panelInfo.add(labelTime);
        panelInfo.add(labelUser);

        /**
         * afegeix al panel principal
         */
        panelMain.add(panelInfo, BorderLayout.NORTH);
    }

    /**
     * afegeix al panel principal
     */
    private void showPanelGame() {
        panelMain.add(panelGame, BorderLayout.CENTER);
    }

    /**
     * crea les parelles de cartes
     */
    private void initializePairs() {
        /**
         * agrupa index amb text de la carta
         */
        Map<String, List<Integer>> valueToPositions = new HashMap<>();
        for (int i = 0; i < gameCards.length; i++) {
            String value = gameCards[i];
            valueToPositions.computeIfAbsent(value, k -> new ArrayList<>()).add(i);
        }

        /**
         * guarda parella de index de cartes amb el mateix text
         */
        for (List<Integer> positions : valueToPositions.values()) {
            if (positions.size() == 2) {
                int firstPos = positions.get(0);
                int secondPos = positions.get(1);
                cardPairs.put(firstPos, secondPos);
            }
        }
    }

    /**
     * agafa parelles i les barreja aleatòriament
     */
    private void createCardPairs() {
        String[] cardPairs = new String[TOTAL_PAIRS * 2];
        for (int i = 0; i < TOTAL_PAIRS; i++) {
            cardPairs[i * 2] = CARD_VALUES[i];
            cardPairs[i * 2 + 1] = CARD_VALUES[i];
        }

        List<String> cardList = Arrays.asList(cardPairs);
        Collections.shuffle(cardList);
        gameCards = cardList.toArray(new String[0]);
        initializePairs();
    }

    /**
     * defienix disseny de les cartes
     */
    private void createCardsDesign() {
        for (int i = 0; i < cards.length; i++) {
            cards[i] = new JButton();
            cards[i].setFont(new Font("Arial", Font.BOLD, 50));
            cards[i].setForeground(Color.BLACK);
            cards[i].setBackground(Color.LIGHT_GRAY);
            cards[i].setOpaque(true);
            cards[i].setBorder(BorderFactory.createLineBorder(Color.gray, 2));
            /**
             * inicialitza @see CardClickListener()
             */
            cards[i].addActionListener(new CardClickListener(i));
            /**
             * afegeix cartes al panel
             */
            panelGame.add(cards[i]);
        }
    }

    /**
     * torna a valors inicials després de cada torn
     */
    private void resetValues() {
        firstCardIndex = -1;
        secondCardIndex = -1;
        isProcessing = false;
    }

    /**
     * classe per configurar clicks sobre les cartes
     */
    private class CardClickListener implements ActionListener {
        private final int cardIndex;

        /**
         * guarda index de la carta girada
         * @param index
         */
        public CardClickListener(int index) {
            this.cardIndex = index;
        }

        @Override
        public void actionPerformed(ActionEvent e) {

            /**
             * impedeix que comenci un torn nou si encara no s'ha acabat
             */
            if (!cards[cardIndex].isEnabled() || isProcessing) return;


            /**
             * guarda carta com a ja revelada
             */
            revealedCards.add(cardIndex);

            /**
             * cada cop que es clica una carta +1 al comptador (value del map)
             * valor default és 0 abans de que es cliqui
             */
            cardRevealCount.put(cardIndex, cardRevealCount.getOrDefault(cardIndex, 0) + 1);

            /**
             * mostra text de la carta i canvia color fons
             */
            cards[cardIndex].setText(gameCards[cardIndex]);
            cards[cardIndex].setBackground(Color.WHITE);

            /**
             * quan es compleix el valor incial vol dir que és la primera carta de la ronda i es guarda l'index
             */
            if (firstCardIndex == -1) {
                firstCardIndex = cardIndex;

            } else {
                /**
                 * sino guarda index de segona carta
                 */
                secondCardIndex = cardIndex;
                /**
                 * evita que es pugui girar una tercer carta
                 */
                isProcessing = true;

                /**
                 * comprova els contingut dels dos index siguin iguals per saber si son parella
                 */
                if (gameCards[firstCardIndex].equals(gameCards[secondCardIndex])) {
                    /**
                     * en cas de ser tenir el mateix contingut, comprova si es la primera vegada que es giren les dues
                     */
                    boolean firstTimePair = cardRevealCount.get(firstCardIndex) == 1 &&
                            cardRevealCount.get(secondCardIndex) == 1;

                    /**
                     * si es la primera vegada que les dues es giren es sumen 5 punts
                     * si una ja s'havia girat es suma un punt
                     */
                    if (firstTimePair) {
                        pointsCounter = pointsCounter + 5;
                    } else {
                        pointsCounter++;
                    }

                    /**
                     * compta parelles trobades
                     */
                    foundPairs++;
                    /**
                     * canvia color de les cartes trobades
                     */
                    cards[firstCardIndex].setEnabled(false);
                    cards[secondCardIndex].setEnabled(false);
                    cards[firstCardIndex].setBackground(Color.GREEN);
                    cards[secondCardIndex].setBackground(Color.GREEN);

                    /**
                     * comprova si ja s'han trobat totes les parelles
                     */
                    if (foundPairs == TOTAL_PAIRS) {
                        /**
                         * para temporitzador
                         */
                        gameTimer.stop();
                        /**
                         * guarda dades partida per després posar-les a la BD
                         */
                        MemoryGame.this.pointsDB = pointsCounter;
                        MemoryGame.this.errorsDB = errorPoints;
                        MemoryGame.this.durationSecondsDB = seconds;

                        /**
                         * mostra finestra quan es guanya
                         */
                        JOptionPane.showMessageDialog(panelMain,
                                "Felicitats! Has guanyat amb: " + pointsCounter + " punts!! \n" +
                                        "Durada del joc: " + seconds + "s",
                                "Game Over",
                                JOptionPane.INFORMATION_MESSAGE);

                        saveGameStats();
                    }
                    resetValues();

                    /**
                     * en cas de no cioncidir les parelles
                      */
                } else {
                    /**
                     * suma un error
                     */
                    errorPoints++;
                    /**
                     * deixa les cartes girades 1 segon abans de tornar-les a amagar
                     */
                    Timer flipBackTimer = new Timer(1000, event -> {
                        cards[firstCardIndex].setText("");
                        cards[secondCardIndex].setText("");
                        cards[firstCardIndex].setBackground(Color.LIGHT_GRAY);
                        cards[secondCardIndex].setBackground(Color.LIGHT_GRAY);
                        resetValues();
                        isProcessing = false;
                    });
                    flipBackTimer.setRepeats(false);
                    flipBackTimer.start();
                }
            }
        }
    }

    /**
     * guarda dades partida per passar-les a la BD
     */
    private void saveGameStats() {
        try {
            DatabaseManager.saveGame(
                    this.username,
                    this.pointsDB,
                    this.errorsDB,
                    this.durationSecondsDB
            );
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame,
                    "No s'han pogut desar les estadístiques: " + e.getMessage(),
                    "Error de base de dades",
                    JOptionPane.WARNING_MESSAGE);
        }
    }
}

