package database;

import java.sql.*;

public class DatabaseManager {


    /**
     * crea connexió amb la BD
     * el user i password han de coincidir amb els de la nostra connexió
     */
    protected static String dataBaseURL = "jdbc:mysql://localhost:3306/gamememory";
    protected static String user = "julia";
    protected static String password = "julia";

    /**
     * defineix inserts que es faran a la BD
     * els noms de les columnes han de coincidir amb el de la BD
     * cada ? representa el valor que s'afegirà a la columna que coincideixi en la posició (ex. el primer ? va a la columna id_jugador)
     */
    private static String insertTableJugadors = "insert into jugadors (username) values (?)";
    private static String insertTablePartides = "insert into partides (id_jugador, punts, `errors`, durada_partida, hora_partida) values (?, ?, ?, ?, ?)";


    /**
     * inserts a les taules amb els paràmetres passats de MemoryGame
     * @param username
     * @param points
     * @param errors
     * @param duration
     */
    public static void saveGame(String username, int points, int errors, int duration) {

        /**
         * guardar id del jugador per poder-la inserir a la taula de partides com a fk
         */
        int jugadorId;

        /**
         * connecta a la BD amb dades definides anteriorment
         */
        try {
            Connection con = DriverManager.getConnection(dataBaseURL, user, password);

            /**
             * insereix dades a la taula jugadors
             */
            try (PreparedStatement psInsertJugador = con.prepareStatement(insertTableJugadors, Statement.RETURN_GENERATED_KEYS)) {
                /**
                 * insereix username i executa la inserció de dades
                 */
                psInsertJugador.setString(1, username);
                psInsertJugador.executeUpdate();

                /**
                 * agafa id generat
                 */
                ResultSet rs = psInsertJugador.getGeneratedKeys();
                if (rs.next()) {
                    /**
                     * guarda id recuperat a la variable
                     */
                    jugadorId = rs.getInt(1);
                } else {
                    throw new SQLException("No s'ha pogut obtenir l'ID del jugador.");
                }
            }

            /**
             * insereix dades a la taula partides
             */
            try {
                PreparedStatement psPartides = con.prepareStatement(insertTablePartides);

                /**
                 * index és la posició de l'interrogant del insert
                 */
                psPartides.setInt(1, jugadorId);
                psPartides.setInt(2, points);
                psPartides.setInt(3, errors);
                psPartides.setInt(4, duration);
                /**
                 * genera timestamp de quan es guarden les dades
                 */
                psPartides.setTimestamp(5, new Timestamp(System.currentTimeMillis()));

                /**
                 * comprova que les dades s'han inserit mirant que s'hagi afegit més de 0 files
                 */
                int addRowsPartides = psPartides.executeUpdate();

                if (addRowsPartides > 0) {
                    System.out.println("S'han insertat les dades correctament");
                    showRank();
                } else {System.out.println("Hi ha hagut un problema inserint els registres a la taula partides."); }

                /**
                 * tanca connection i preparedstatement
                 */
                psPartides.close();
                con.close();


            } catch (Exception e) {
                System.out.println("No s'han pogut inserir els registres a la taula partides.");
            }

        } catch (SQLException e) {
            System.out.println("La connexió amb la base de dades ha fallat");
        }
    }

    /**
     * crida mètode per crear rànquing de jugadors
     */
    public static void showRank() {
        DatabaseRank.showTopPlayers();
    }
}


