package database;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

/**
 * crea ranquing de 10 millors jugadors per punts
 */
public class DatabaseRank {

    /**
     * query per trobar els jugadors i recuperar dades que es volen mostrar
     */
    private static final String TOP_PLAYERS_QUERY =
            "SELECT jugadors.username, partides.punts, partides.errors, partides.durada_partida " +
                    "FROM jugadors JOIN partides ON jugadors.id = partides.id_jugador " +
                    "ORDER BY partides.punts DESC LIMIT 10";

    /**
     * mostra top10 jugadors
     */
    public static void showTopPlayers() {
        /**
         * defineix frame
         */
        JFrame frame = new JFrame("Top 10 jugadors per punts");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        /**
         * crea el model de la taula
         */
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Username");
        model.addColumn("Punts");
        model.addColumn("Errors");
        model.addColumn("Durada (s)");

        /**
         * crea taula
         * afegeix a frame
         */
        JTable table = new JTable(model);
        frame.add(new JScrollPane(table), BorderLayout.CENTER);

        /**
         * carrega les dades des de la base de dades
         */
        try (Connection con = DriverManager.getConnection(
                DatabaseManager.dataBaseURL,
                DatabaseManager.user,
                DatabaseManager.password);
             /**
              * fa query amb login info passades de DatabaseManager
              */
             PreparedStatement ps = con.prepareStatement(TOP_PLAYERS_QUERY);
             ResultSet rs = ps.executeQuery()) {

            /**
             * afegeix resultats de la query a la columna corresponent
             */
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("username"),
                        rs.getInt("punts"),
                        rs.getInt("errors"),
                        rs.getInt("durada_partida")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame,
                    "Error carregant dades: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }

        /**
         * defineix frame com a visible
         */
        frame.setVisible(true);
    }

    /**
     * crida mètode anterior
     */
    public static void main(String[] args) {
        showTopPlayers();
    }
}
