package Main;

import forms.FrontPage;

/**
 * Crea nova instància de {@link forms.FrontPage} cridant al constructor
 */


public class Main {
    public static void main(String[] args) {
        new FrontPage();
    }
}





