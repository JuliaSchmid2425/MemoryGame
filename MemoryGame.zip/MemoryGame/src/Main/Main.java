package Main;

import forms.FrontPage;

public class Main {
    public static void main(String[] args) {
        new FrontPage();
    }
}





